<?php
try {
    $dsn = 'mysql:host=localhost;dbname=elcadmin_db'; // Updated to match your database name
    $username = 'elcadmin_user'; // Replace with your MySQL username
    $password = 'Pakistan@123456789'; // Replace with your MySQL password
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}
?>
